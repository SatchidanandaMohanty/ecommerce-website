const slider = document.querySelector('.slider');
const images = slider.querySelectorAll('img');
let counter = 0;

function slide() {
  counter++;
  if (counter === images.length) {
    counter = 0;
  }
  slider.style.transform = `translateX(-${counter * 20}%)`;
}

setInterval(slide, 4000);
